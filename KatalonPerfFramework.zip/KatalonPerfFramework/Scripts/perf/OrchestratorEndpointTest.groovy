/**
 * OrchestratorEndpointTest.groovy - Orchestrator endpoints only
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import com.kms.katalon.core.util.KeywordUtil

ConcurrentRunner.resetCounters()
Map  config   = ConfigLoader.load("config/endpoints.json")
Map  settings = config.global_settings ?: [:]
List eps      = ConfigLoader.filterEndpoints(config.endpoints ?: [], [endpointtype: "Orchestrator"])

KeywordUtil.logInfo("Orchestrator endpoints: ${eps.size()}")
int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

List<Map> rawResults  = []
List<Map> summaryRows = []

eps.each { ep ->
    String lbl = ep.responsetype?.equalsIgnoreCase("Streaming") ? "STREAM" : "REST"
    KeywordUtil.logInfo("[${lbl}] ${ConfigLoader.nameOf(ep)}")
    List<Map> results = ConcurrentRunner.runConcurrent(ep, concurrent, runs)
    rawResults.addAll(results)
    summaryRows << ConcurrentRunner.computeAverages(ep, results)
}

if (rawResults) {
    String path = ReportGenerator.generate(summaryRows, rawResults,
        settings + [report_prefix: "Orchestrator"])
    KeywordUtil.logInfo("Report: ${path}")
}
ConcurrentRunner.logFailureSummary()
