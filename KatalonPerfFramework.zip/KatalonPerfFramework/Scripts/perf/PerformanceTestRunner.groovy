/**
 * PerformanceTestRunner.groovy - Main test case
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import com.kms.katalon.core.util.KeywordUtil

ConcurrentRunner.resetCounters()
List<Map> allRaw       = []
List<Map> allSummaries = []

String cliUrl = System.getProperty("perf.url")
Map config
List<Map> endpoints

if (cliUrl) {
    Map cliEp = ConfigLoader.buildFromCli()
    endpoints = [cliEp]
    config = [global_settings: [
        concurrent_users: (System.getProperty("perf.concurrent", "3") as int),
        runs_per_endpoint: (System.getProperty("perf.runs", "3") as int),
        report_prefix: "PerfTest_CLI", output_directory: "Reports",
        stakeholders: ["Jeff","Andy","Richmond","Chay","Subha","Lakshmi","Patrick","Hugh"]
    ]]
    KeywordUtil.logInfo("CLI mode -> ${cliEp.url}")
} else {
    config = ConfigLoader.load("config/endpoints.json")
    List<Map> all = config.endpoints ?: []
    Map filters = [:]
    if (System.getProperty("perf.env"))          filters.environment  = System.getProperty("perf.env")
    if (System.getProperty("perf.endpointtype")) filters.endpointtype = System.getProperty("perf.endpointtype")
    if (System.getProperty("perf.responsetype")) filters.responsetype = System.getProperty("perf.responsetype")
    endpoints = ConfigLoader.filterEndpoints(all, filters)
    KeywordUtil.logInfo("Running ${endpoints.size()} endpoint(s)")
}

Map settings   = config.global_settings ?: [:]
int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

endpoints.each { ep ->
    String lbl = ep.responsetype?.equalsIgnoreCase("Streaming") ? "STREAM" : "REST"
    KeywordUtil.logInfo("[${lbl}][${ep.endpointtype?:'?'}] ${ConfigLoader.nameOf(ep)}")
    KeywordUtil.logInfo("  ${ep.method} ${ep.url}")
    List<Map> results = ConcurrentRunner.runConcurrent(ep, concurrent, runs)
    allRaw.addAll(results)
    allSummaries << ConcurrentRunner.computeAverages(ep, results)
}

if (allRaw) {
    String path = ReportGenerator.generate(allSummaries, allRaw, settings)
    KeywordUtil.logInfo("Report: ${path}")
} else {
    KeywordUtil.markWarning("No results collected.")
}

ConcurrentRunner.logFailureSummary()
int f = ConcurrentRunner.totalFailures.get()
int t = ConcurrentRunner.totalExecutions.get()
if (t > 0 && (f / t) > 0.20) {
    KeywordUtil.markFailed("Failure rate ${((f/t)*100).round(1)}% exceeds 20% (${f}/${t})")
}
