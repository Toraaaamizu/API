/**
 * CrossEnvironmentComparisonTest.groovy
 * Runs both ENV1 and ENV2, then produces a side-by-side comparison Excel.
 * Green = ENV2 faster/better, Red = ENV2 slower/worse.
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.*
import org.apache.poi.ss.util.CellRangeAddress
import java.text.SimpleDateFormat
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.configuration.RunConfiguration

ConcurrentRunner.resetCounters()

Map  config   = ConfigLoader.load("config/endpoints.json")
Map  settings = config.global_settings ?: [:]
List all      = config.endpoints ?: []

int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

Map<String, List<Map>> resultsByEnv   = [env1: [], env2: []]
Map<String, List<Map>> summaryByEnv   = [env1: [], env2: []]

["env1", "env2"].each { env ->
    List<Map> eps = ConfigLoader.filterEndpoints(all, [environment: env])
    KeywordUtil.logInfo("${env}: ${eps.size()} endpoints")

    eps.each { ep ->
        List<Map> res = ConcurrentRunner.runConcurrent(ep, concurrent, runs)
        resultsByEnv[env].addAll(res)
        summaryByEnv[env] << ConcurrentRunner.computeAverages(ep, res)
    }
}

// Individual environment reports
["env1","env2"].each { env ->
    if (resultsByEnv[env]) {
        ReportGenerator.generate(summaryByEnv[env], resultsByEnv[env],
            settings + [report_prefix: "PerfTest_${env.toUpperCase()}"])
    }
}

// Cross-environment comparison report
buildComparison(summaryByEnv.env1, summaryByEnv.env2, settings, config.environments ?: [:])
ConcurrentRunner.logFailureSummary()

void buildComparison(List<Map> e1, List<Map> e2, Map settings, Map envMeta) {
    String outDir = settings.output_directory ?: "Reports"
    File dir
    try { dir = new File(RunConfiguration.getProjectDir(), outDir) }
    catch (Exception ignored) { dir = new File(System.getProperty("user.dir"), outDir) }
    if (!dir.exists()) dir.mkdirs()

    String ts = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())
    File out  = new File(dir, "PerfTest_ENV_COMPARISON_${ts}.xlsx")
    XSSFWorkbook wb = new XSSFWorkbook()
    XSSFSheet s     = wb.createSheet("ENV1 vs ENV2")
    s.createFreezePane(0, 2)

    // Fonts
    XSSFFont boldW  = wb.createFont(); boldW.setBold(true); boldW.setFontName("Arial"); boldW.setFontHeightInPoints((short)10); boldW.setColor(IndexedColors.WHITE.index)
    XSSFFont plain  = wb.createFont(); plain.setFontName("Arial"); plain.setFontHeightInPoints((short)10)
    XSSFFont bold   = wb.createFont(); bold.setBold(true); bold.setFontName("Arial"); bold.setFontHeightInPoints((short)10)

    Closure hdrStyle = { byte[] rgb ->
        XSSFCellStyle st = wb.createCellStyle()
        st.setFillForegroundColor(new XSSFColor(rgb))
        st.setFillPattern(FillPatternType.SOLID_FOREGROUND)
        st.setFont(boldW); st.setAlignment(HorizontalAlignment.CENTER)
        st.setBorderBottom(BorderStyle.THIN); return st
    }
    Closure numSt = { byte[] rgb = null ->
        XSSFCellStyle st = wb.createCellStyle()
        st.setFont(rgb ? bold : plain)
        if (rgb) { st.setFillForegroundColor(new XSSFColor(rgb)); st.setFillPattern(FillPatternType.SOLID_FOREGROUND) }
        st.setDataFormat(wb.createDataFormat().getFormat("#,##0.00"))
        st.setAlignment(HorizontalAlignment.RIGHT); return st
    }
    XSSFCellStyle dataSt  = wb.createCellStyle(); dataSt.setFont(plain); dataSt.setBorderBottom(BorderStyle.HAIR)
    XSSFCellStyle greenSt = numSt([198, 239, 206] as byte[])
    XSSFCellStyle redSt   = numSt([255, 199, 206] as byte[])
    XSSFCellStyle numPlain = numSt()

    // Row 0: group headers
    String e1Label = "ENV1 – ${envMeta.env1?.orchestrator_base ?: ':9090/:9091'}"
    String e2Label = "ENV2 – ${envMeta.env2?.orchestrator_base ?: ':9010/:9001'}"
    XSSFRow r0 = s.createRow(0)
    [[0,2,"Endpoint"], [3,7,e1Label], [8,12,e2Label], [13,15,"Delta (ENV2 - ENV1)"]].each { col1, col2, lbl ->
        XSSFCell c = r0.createCell(col1 as int)
        c.setCellValue(lbl as String)
        byte[] rgb = lbl.toString().contains("ENV1") ? [31,73,125] as byte[] :
                     lbl.toString().contains("ENV2") ? [68,114,196] as byte[] :
                     [89,89,89] as byte[]
        c.setCellStyle(hdrStyle(rgb))
        if (col1 != col2) s.addMergedRegion(new CellRangeAddress(0,0,col1 as int,col2 as int))
    }

    // Row 1: column names
    XSSFRow r1 = s.createRow(1)
    ["Name","Type","Resp Type",
     "Avg Response","TTFT","Output Tokens","Throughput","Success%",
     "Avg Response","TTFT","Output Tokens","Throughput","Success%",
     "Delta Response","Delta TTFT","Delta Success%"].eachWithIndex { h, i ->
        XSSFCell c = r1.createCell(i); c.setCellValue(h)
        c.setCellStyle(hdrStyle([89,89,89] as byte[]))
    }

    // Build env2 lookup by normalised id
    Map<String, Map> e2Map = [:]
    e2.each { row -> e2Map[row.endpointId?.replace("e2-","e1-")] = row }

    int rowIdx = 2
    e1.each { row1 ->
        Map row2 = e2Map[row1.endpointId] ?: [:]
        XSSFRow dr = s.createRow(rowIdx++)

        // Labels
        [row1.endpointName, row1.endpointType, row1.responseType].eachWithIndex { v, i ->
            XSSFCell c = dr.createCell(i); c.setCellValue(v?.toString()?:""); c.setCellStyle(dataSt)
        }

        // ENV1 metrics
        [row1.avgTotalResponseTimeMs, row1.avgTimeToFirstTokenMs, row1.avgOutputTokens,
         row1.throughputReqPerSec, row1.successRate].eachWithIndex { v, i ->
            XSSFCell c = dr.createCell(3+i)
            if (v == "-" || v == null) { c.setCellValue("-"); c.setCellStyle(dataSt) }
            else { c.setCellValue(v as double); c.setCellStyle(numPlain) }
        }
        // ENV2 metrics
        [row2.avgTotalResponseTimeMs, row2.avgTimeToFirstTokenMs, row2.avgOutputTokens,
         row2.throughputReqPerSec, row2.successRate].eachWithIndex { v, i ->
            XSSFCell c = dr.createCell(8+i)
            if (v == "-" || v == null) { c.setCellValue("-"); c.setCellStyle(dataSt) }
            else { c.setCellValue(v as double); c.setCellStyle(numPlain) }
        }
        // Deltas: response, TTFT, success%
        [[row2.avgTotalResponseTimeMs, row1.avgTotalResponseTimeMs],
         [row2.avgTimeToFirstTokenMs,  row1.avgTimeToFirstTokenMs],
         [row2.successRate,            row1.successRate]].eachWithIndex { pair, i ->
            XSSFCell c = dr.createCell(13+i)
            def v2 = pair[0]; def v1 = pair[1]
            if (v2=="-"||v1=="-"||v2==null||v1==null) { c.setCellValue("-"); c.setCellStyle(dataSt) }
            else {
                double delta = (v2 as double) - (v1 as double)
                c.setCellValue(delta)
                boolean better = (i < 2) ? delta < 0 : delta > 0
                c.setCellStyle(better ? greenSt : redSt)
            }
        }
    }

    16.times { i ->
        s.autoSizeColumn(i)
        s.setColumnWidth(i, Math.min(s.getColumnWidth(i)+512, 14000))
    }

    FileOutputStream fos = new FileOutputStream(out); wb.write(fos); fos.close(); wb.close()
    KeywordUtil.logInfo("Comparison report: ${out.absolutePath}")
}
