/**
 * EnvironmentTest.groovy - Run one environment at a time
 * Usage: -Dperf.env=env1  or  -Dperf.env=env2
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import com.kms.katalon.core.util.KeywordUtil

ConcurrentRunner.resetCounters()
String targetEnv = System.getProperty("perf.env", "env1")

Map  config   = ConfigLoader.load("config/endpoints.json")
Map  settings = config.global_settings ?: [:]
Map  envMeta  = config.environments?."${targetEnv}" ?: [:]
List all      = config.endpoints ?: []
List<Map> eps = ConfigLoader.filterEndpoints(all, [environment: targetEnv])

KeywordUtil.logInfo("=== ${targetEnv.toUpperCase()} | ${eps.size()} endpoints ===")
KeywordUtil.logInfo("  Orchestrator: ${envMeta.orchestrator_base}")
KeywordUtil.logInfo("  RAG:          ${envMeta.rag_base}")
KeywordUtil.logInfo("  Connected to: ${envMeta.connected_to}")

int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

List<Map> rawResults  = []
List<Map> summaryRows = []

eps.each { ep ->
    String lbl = ep.responsetype?.equalsIgnoreCase("Streaming") ? "STREAM" : "REST"
    KeywordUtil.logInfo("[${lbl}][${ep.endpointtype?:'?'}] ${ConfigLoader.nameOf(ep)}")
    List<Map> results = ConcurrentRunner.runConcurrent(ep, concurrent, runs)
    rawResults.addAll(results)
    summaryRows << ConcurrentRunner.computeAverages(ep, results)
}

if (rawResults) {
    String path = ReportGenerator.generate(summaryRows, rawResults,
        settings + [report_prefix: "PerfTest_${targetEnv.toUpperCase()}"])
    KeywordUtil.logInfo("Report: ${path}")
}
ConcurrentRunner.logFailureSummary()
