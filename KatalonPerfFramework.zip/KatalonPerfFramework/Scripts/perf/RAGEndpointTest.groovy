/**
 * RAGEndpointTest.groovy - RAG (endpointtype = "Rag") endpoints only
 * Supports data scenario injection via Data Files/rag_queries.json
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import groovy.json.JsonSlurper
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.configuration.RunConfiguration

ConcurrentRunner.resetCounters()
Map  config   = ConfigLoader.load("config/endpoints.json")
Map  settings = config.global_settings ?: [:]
List eps      = ConfigLoader.filterEndpoints(config.endpoints ?: [], [endpointtype: "Rag"])

// Optional scenario injection
List<Map> scenarios = []
try {
    File f = new File(RunConfiguration.getProjectDir(), "Data Files/rag_queries.json")
    if (f.exists()) scenarios = (List<Map>) new JsonSlurper().parseText(f.getText("UTF-8"))
} catch (Exception ignored) {}

KeywordUtil.logInfo("RAG endpoints: ${eps.size()} | Scenarios: ${scenarios.size()}")
int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

List<Map> rawResults  = []
List<Map> summaryRows = []

eps.each { ep ->
    List<Map> variants = scenarios ? scenarios.withIndex().collect { scenario, idx ->
        Map v = new HashMap(ep)
        Map body = ep.payload ? new HashMap(ep.payload) : [:]
        scenario.each { k, val -> body[k] = val }
        v.payload = body
        v._id   = "${ep._id}_s${idx+1}"
        v._name = "${ep._name ?: ConfigLoader.nameOf(ep)} [S${idx+1}]"
        return v
    } : [ep]

    variants.each { v ->
        KeywordUtil.logInfo("[RAG] ${ConfigLoader.nameOf(v)}")
        List<Map> results = ConcurrentRunner.runConcurrent(v, concurrent, runs)
        rawResults.addAll(results)
        summaryRows << ConcurrentRunner.computeAverages(v, results)
    }
}

if (rawResults) {
    String path = ReportGenerator.generate(summaryRows, rawResults,
        settings + [report_prefix: "RAG"])
    KeywordUtil.logInfo("Report: ${path}")
}
ConcurrentRunner.logFailureSummary()
