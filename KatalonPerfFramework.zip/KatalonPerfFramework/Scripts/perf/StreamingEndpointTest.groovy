/**
 * StreamingEndpointTest.groovy - Streaming (SSE) endpoints only
 * Filters on responsetype = "Streaming"
 */
import utils.ConfigLoader
import utils.ConcurrentRunner
import utils.ReportGenerator
import com.kms.katalon.core.util.KeywordUtil

ConcurrentRunner.resetCounters()
Map  config   = ConfigLoader.load("config/endpoints.json")
Map  settings = config.global_settings ?: [:]
List eps      = ConfigLoader.filterEndpoints(config.endpoints ?: [], [responsetype: "Streaming"])

KeywordUtil.logInfo("Streaming endpoints: ${eps.size()}")
int concurrent = (settings.concurrent_users  ?: 5) as int
int runs       = (settings.runs_per_endpoint ?: 3) as int

List<Map> rawResults  = []
List<Map> summaryRows = []

eps.each { ep ->
    KeywordUtil.logInfo("[STREAM][${ep.endpointtype?:'?'}] ${ConfigLoader.nameOf(ep)}")
    List<Map> results = ConcurrentRunner.runConcurrent(ep, concurrent, runs)

    // Streaming-specific assertions
    results.findAll { it.success }.each { r ->
        if ((r.timeToFirstTokenMs as long) <= 0)
            KeywordUtil.markWarning("[${r.endpointId}] TTFT not measured - check SSE stream is live")
        if ((r.outputTokens as int) <= 0)
            KeywordUtil.markWarning("[${r.endpointId}] Output token count is 0 - verify SSE delta parsing")
    }

    rawResults.addAll(results)
    summaryRows << ConcurrentRunner.computeAverages(ep, results)
}

if (rawResults) {
    String path = ReportGenerator.generate(summaryRows, rawResults,
        settings + [report_prefix: "StreamingTest"])
    KeywordUtil.logInfo("Report: ${path}")
}
ConcurrentRunner.logFailureSummary()
