package utils

import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import groovy.json.JsonOutput
import com.kms.katalon.core.util.KeywordUtil

/**
 * PerfHttpClient – HTTP execution engine.
 *
 * Reads the canonical endpoint schema fields:
 *   url, method, endpointtype, responsetype, payload, headers, cert, timeout
 *
 * responsetype drives metric collection:
 *   "Streaming"    → SSE parsing, TTFT, TTLT, output token count
 *   "NonStreaming"  → total response time only; token fields set to "-"
 *
 * cert supports:
 *   [certPath, keyPath]  – PEM cert + key (mutual TLS)
 *   "certPath"           – cert only
 *   null / omitted       – no client cert (still accepts self-signed server certs)
 */
class PerfHttpClient {

    /**
     * Execute one request and return a populated PerfResult map.
     */
    static Map execute(Map ep) {
        String  method       = (ep.method ?: "POST").toUpperCase()
        String  urlStr       = ep.url
        Map     headers      = ep.headers ?: [:]
        def     payload      = ep.payload
        String  responseType = ep.responsetype ?: "Streaming"
        boolean isStreaming  = responseType.equalsIgnoreCase("Streaming")
        int     timeoutMs    = (int)(((ep.timeout ?: 120.0) as double) * 1000)

        PerfResult result = new PerfResult(
            endpointId:   ConfigLoader.idOf(ep),
            endpointName: ConfigLoader.nameOf(ep),
            endpointType: ep.endpointtype ?: "",
            responseType: responseType,
            environment:  ep._environment ?: "",
            method:       method,
            url:          urlStr
        )

        String bodyJson = (payload != null) ? JsonOutput.toJson(payload) : ""
        result.inputTokens = estimateTokenCount(bodyJson)

        HttpURLConnection conn = null
        try {
            URL url = new URL(urlStr)
            conn = openConnection(url, ep.cert)
            conn.setRequestMethod(method)
            conn.setConnectTimeout(timeoutMs)
            conn.setReadTimeout(timeoutMs)
            conn.setDoInput(true)

            headers.each { k, v -> conn.setRequestProperty(k.toString(), v.toString()) }

            if (["POST", "PUT", "PATCH"].contains(method) && bodyJson) {
                conn.setDoOutput(true)
                OutputStream os = conn.getOutputStream()
                os.write(bodyJson.getBytes("UTF-8"))
                os.flush()
                os.close()
            }

            // Measure connection establishment (stream start time)
            long t0 = System.currentTimeMillis()
            conn.connect()
            result.streamStartTimeMs = System.currentTimeMillis() - t0

            int status = conn.getResponseCode()
            result.httpStatus = status

            if (status >= 200 && status < 300) {
                long responseStart = System.currentTimeMillis()
                if (isStreaming) {
                    readStreamingResponse(conn, result, responseStart)
                } else {
                    readNonStreamingResponse(conn, result, responseStart)
                }
            } else {
                result.error   = "HTTP ${status}: ${conn.getResponseMessage()}"
                result.success = false
            }

        } catch (java.net.SocketTimeoutException e) {
            result.error   = "Timeout (${timeoutMs}ms): ${e.getMessage()}"
            result.success = false
            KeywordUtil.markWarning("Timeout [${result.endpointId}]: ${e.getMessage()}")
        } catch (Exception e) {
            result.error   = "${e.getClass().getSimpleName()}: ${e.getMessage()}"
            result.success = false
            KeywordUtil.markWarning("Error [${result.endpointId}]: ${e.getMessage()}")
        } finally {
            conn?.disconnect()
        }

        return result.toMap()
    }

    // ── Streaming reader (SSE) ────────────────────────────────────────────────

    private static void readStreamingResponse(HttpURLConnection conn, PerfResult result, long t0) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))
        StringBuilder fullContent = new StringBuilder()
        boolean firstToken = false
        int tokenCount = 0
        String line

        while ((line = reader.readLine()) != null) {
            if (!firstToken && line.trim()) {
                result.timeToFirstTokenMs = System.currentTimeMillis() - t0
                firstToken = true
            }
            String content = extractSSEContent(line)
            if (content) {
                fullContent.append(content)
                tokenCount += estimateTokenCount(content)
            }
        }
        reader.close()

        long elapsed = System.currentTimeMillis() - t0
        result.timeToLastTokenMs   = elapsed
        result.totalResponseTimeMs = elapsed
        result.outputTokens        = tokenCount
        result.responseBody        = fullContent.toString()
        result.success             = true
    }

    // ── Non-streaming reader ──────────────────────────────────────────────────

    private static void readNonStreamingResponse(HttpURLConnection conn, PerfResult result, long t0) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))
        StringBuilder sb = new StringBuilder()
        String line
        while ((line = reader.readLine()) != null) sb.append(line)
        reader.close()

        result.totalResponseTimeMs = System.currentTimeMillis() - t0
        result.responseBody        = sb.toString()
        result.success             = true
        // timeToFirstTokenMs, timeToLastTokenMs, outputTokens → remain 0
        // toMap() will output "-" for these when responseType is NonStreaming
    }

    // ── Connection factory with cert support ──────────────────────────────────

    private static HttpURLConnection openConnection(URL url, def certConfig) {
        HttpURLConnection conn

        if (url.protocol == "https") {
            HttpsURLConnection httpsConn = (HttpsURLConnection) url.openConnection()

            // Build trust-all context for internal self-signed certs
            TrustManager[] trustAll = [new X509TrustManager() {
                X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0] }
                void checkClientTrusted(X509Certificate[] certs, String authType) {}
                void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }]

            SSLContext sslCtx = SSLContext.getInstance("TLS")

            if (certConfig) {
                // Client certificate (mutual TLS)
                try {
                    KeyManagerFactory kmf = loadClientCert(certConfig)
                    sslCtx.init(kmf.getKeyManagers(), trustAll, null)
                } catch (Exception e) {
                    KeywordUtil.markWarning("Client cert load failed (${e.getMessage()}); falling back to no-cert TLS")
                    sslCtx.init(null, trustAll, null)
                }
            } else {
                sslCtx.init(null, trustAll, null)
            }

            httpsConn.setSSLSocketFactory(sslCtx.getSocketFactory())
            httpsConn.setHostnameVerifier { hostname, session -> true }
            conn = httpsConn
        } else {
            conn = (HttpURLConnection) url.openConnection()
        }

        return conn
    }

    private static KeyManagerFactory loadClientCert(def certConfig) {
        // certConfig can be [certPath, keyPath] or "certPath"
        String certPath = (certConfig instanceof List) ? certConfig[0] : certConfig.toString()

        // Load PEM certificate
        CertificateFactory cf = CertificateFactory.getInstance("X.509")
        FileInputStream certIn = new FileInputStream(resolveCertPath(certPath))
        X509Certificate cert   = (X509Certificate) cf.generateCertificate(certIn)
        certIn.close()

        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null, null)
        ks.setCertificateEntry("client", cert)

        if (certConfig instanceof List && certConfig.size() >= 2) {
            // Load private key if provided (simplified – real impl needs PKCS8 parsing)
            // For environments where key loading via Java keystore is needed,
            // replace this block with a proper PEM key reader (e.g. Bouncy Castle).
            KeywordUtil.logInfo("Client key path noted: ${certConfig[1]} (key loading requires Bouncy Castle in classpath)")
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, "".toCharArray())
        return kmf
    }

    private static String resolveCertPath(String path) {
        File f = new File(path)
        if (f.isAbsolute() && f.exists()) return f.absolutePath
        try {
            File projectDir = new File(com.kms.katalon.core.configuration.RunConfiguration.getProjectDir())
            File resolved = new File(projectDir, path)
            if (resolved.exists()) return resolved.absolutePath
        } catch (Exception ignored) {}
        return path
    }

    // ── SSE content extractor ─────────────────────────────────────────────────

    static String extractSSEContent(String line) {
        if (!line || line == "data: [DONE]") return ""
        if (line.startsWith("data: ")) {
            String jsonStr = line.substring(6).trim()
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(jsonStr)
                // OpenAI-style delta
                def delta = parsed?.choices?.getAt(0)?.delta?.content
                if (delta != null) return delta.toString()
                // Generic content field
                if (parsed?.content) return parsed.content.toString()
                // token field (some RAG APIs)
                if (parsed?.token) return parsed.token.toString()
            } catch (Exception ignored) {
                return jsonStr  // raw chunk
            }
        }
        return ""
    }

    // ── Token estimator (1 token ≈ 4 chars) ──────────────────────────────────

    static int estimateTokenCount(String text) {
        if (!text) return 0
        return Math.max(1, (int)(text.trim().length() / 4.0))
    }
}
