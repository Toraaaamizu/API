package utils

import groovy.json.JsonSlurper
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.util.KeywordUtil

/**
 * ConfigLoader – Reads endpoints.json using the canonical schema:
 *   url, method, endpointtype, responsetype, payload, headers, cert, timeout
 *
 * Metadata fields prefixed with "_" are for human readability only:
 *   _id, _name, _environment
 *
 * Resolves {{PLACEHOLDER}} tokens from system properties or environment variables.
 */
class ConfigLoader {

    static final String DEFAULT_CONFIG_PATH = "config/endpoints.json"

    // ── Load full config ──────────────────────────────────────────────────────

    static Map load(String configPath = DEFAULT_CONFIG_PATH) {
        File configFile = resolveFile(configPath)

        if (!configFile.exists()) {
            KeywordUtil.markFailed("Config not found: ${configFile.absolutePath}")
            throw new FileNotFoundException("Config not found: ${configFile.absolutePath}")
        }

        String rawJson = resolvePlaceholders(configFile.getText("UTF-8"))
        Map config = (Map) new JsonSlurper().parseText(rawJson)

        int total = config.endpoints?.size() ?: 0
        KeywordUtil.logInfo("Loaded ${total} endpoint(s) from ${configFile.name}")
        return config
    }

    // ── Filter endpoints ──────────────────────────────────────────────────────

    /**
     * Filter the endpoints list.
     * Supported filter keys:
     *   endpointtype  – "Orchestrator" | "Rag"  (matches endpointtype field)
     *   responsetype  – "Streaming" | "NonStreaming"
     *   environment   – "env1" | "env2"  (matches _environment metadata field)
     *   _id           – exact _id match
     */
    static List<Map> filterEndpoints(List<Map> endpoints, Map filters = [:]) {
        return endpoints.findAll { ep ->
            boolean typeMatch   = !filters.endpointtype  || ep.endpointtype?.equalsIgnoreCase(filters.endpointtype as String)
            boolean respMatch   = !filters.responsetype  || ep.responsetype?.equalsIgnoreCase(filters.responsetype as String)
            boolean envMatch    = !filters.environment   || ep._environment == filters.environment
            boolean idMatch     = !filters._id           || ep._id == filters._id
            typeMatch && respMatch && envMatch && idMatch
        }
    }

    // ── Derive a display name for an endpoint ─────────────────────────────────

    /**
     * Returns _name if set, otherwise derives a readable name from the URL path.
     */
    static String nameOf(Map ep) {
        if (ep._name) return ep._name
        try {
            String path = new URL(ep.url as String).path
            return path ?: ep.url
        } catch (Exception ignored) {
            return ep.url ?: "unknown"
        }
    }

    /**
     * Returns _id if set, otherwise a sanitised URL path segment.
     */
    static String idOf(Map ep) {
        if (ep._id) return ep._id
        try {
            String path = new URL(ep.url as String).path
            return path.replaceAll("[^a-zA-Z0-9_-]", "_").replaceAll("_+", "_").take(40)
        } catch (Exception ignored) {
            return "endpoint-${System.currentTimeMillis()}"
        }
    }

    // ── CLI single-endpoint mode ──────────────────────────────────────────────

    /**
     * Build a synthetic endpoint from CLI -D flags.
     * Required: -Dperf.url=...
     * Optional: -Dperf.method, -Dperf.endpointtype, -Dperf.responsetype,
     *           -Dperf.body (JSON string), -Dperf.headers (k=v;k2=v2),
     *           -Dperf.timeout, -Dperf.cert (path1,path2)
     */
    static Map buildFromCli() {
        String url = System.getProperty("perf.url")
        if (!url) return null

        Map ep = [
            _id:          "cli-endpoint",
            _name:        System.getProperty("perf.name", url),
            _environment: "cli",
            url:          url,
            method:       System.getProperty("perf.method", "POST").toUpperCase(),
            endpointtype: System.getProperty("perf.endpointtype", ""),
            responsetype: System.getProperty("perf.responsetype", "Streaming"),
            headers:      parseCLIHeaders(),
            payload:      parseCLIBody(),
            timeout:      (System.getProperty("perf.timeout", "120.0") as double)
        ]

        String certStr = System.getProperty("perf.cert", "")
        if (certStr) {
            def parts = certStr.split(",")
            ep.cert = parts.size() >= 2 ? [parts[0].trim(), parts[1].trim()] : parts[0].trim()
        }

        return ep
    }

    private static Map parseCLIHeaders() {
        Map h = ["Content-Type": "application/json"]
        String raw = System.getProperty("perf.headers", "")
        raw.split(";").each { pair ->
            def parts = pair.split("=", 2)
            if (parts.size() == 2) h[parts[0].trim()] = parts[1].trim()
        }
        return h
    }

    private static def parseCLIBody() {
        String raw = System.getProperty("perf.body", "")
        if (!raw) return null
        try { return new JsonSlurper().parseText(raw) }
        catch (Exception ignored) { return raw }
    }

    // ── Placeholder resolution ────────────────────────────────────────────────

    static String resolvePlaceholders(String text) {
        return text.replaceAll(/\{\{(\w+)\}\}/) { full, key ->
            System.getProperty(key) ?: System.getenv(key) ?: full
        }
    }

    // ── File helpers ──────────────────────────────────────────────────────────

    private static File resolveFile(String path) {
        File f = new File(path)
        if (f.isAbsolute()) return f
        try {
            return new File(RunConfiguration.getProjectDir(), path)
        } catch (Exception ignored) {
            return new File(System.getProperty("user.dir"), path)
        }
    }
}
