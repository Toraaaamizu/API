package utils

import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import com.kms.katalon.core.util.KeywordUtil

/**
 * ConcurrentRunner – Thread-pool execution of API endpoints.
 * Reads canonical schema fields: url, endpointtype, responsetype, timeout
 */
class ConcurrentRunner {

    static final AtomicInteger totalFailures   = new AtomicInteger(0)
    static final AtomicInteger totalExecutions = new AtomicInteger(0)

    /**
     * Run one endpoint under concurrent load.
     * @param ep               Endpoint map (canonical schema)
     * @param concurrentUsers  Number of parallel virtual users
     * @param runsPerUser      Sequential runs per user
     * @return List of result Maps (one per request)
     */
    static List<Map> runConcurrent(Map ep, int concurrentUsers = 5, int runsPerUser = 1) {
        int timeoutMs = (int)(((ep.timeout ?: 120.0) as double) * 1000)
        // Per-future wait = per-request timeout × runs + 10s grace
        long futureTimeoutMs = (long)(timeoutMs * runsPerUser) + 10_000L

        ExecutorService pool = Executors.newFixedThreadPool(concurrentUsers)
        List<Future<List<Map>>> futures = []
        List<Map> allResults = []

        try {
            (1..concurrentUsers).each { userId ->
                futures << pool.submit(new Callable<List<Map>>() {
                    List<Map> call() {
                        List<Map> userResults = []
                        (1..runsPerUser).each { runNum ->
                            Map result = PerfHttpClient.execute(ep)
                            result.runNumber        = runNum
                            result.concurrentUserId = userId
                            result.executedAt       = System.currentTimeMillis()

                            totalExecutions.incrementAndGet()
                            if (!result.success) {
                                totalFailures.incrementAndGet()
                                KeywordUtil.markWarning(
                                    "FAILED [${result.endpointId}] user=${userId} run=${runNum}: ${result.error}"
                                )
                            } else {
                                KeywordUtil.logInfo(
                                    "[${result.endpointId}] user=${userId} run=${runNum} " +
                                    "→ ${result.totalResponseTimeMs}ms HTTP${result.httpStatus}"
                                )
                            }
                            userResults << result
                        }
                        return userResults
                    }
                })
            }

            futures.each { future ->
                try {
                    allResults.addAll(future.get(futureTimeoutMs, TimeUnit.MILLISECONDS))
                } catch (Exception e) {
                    KeywordUtil.markWarning("Thread timed out: ${e.getMessage()}")
                    totalFailures.incrementAndGet()
                }
            }

        } finally {
            pool.shutdown()
            if (!pool.awaitTermination(60, TimeUnit.SECONDS)) pool.shutdownNow()
        }

        return allResults
    }

    /**
     * Compute throughput in requests/second (parallelism-adjusted).
     */
    static double computeThroughput(List<Map> results) {
        List<Map> ok = results.findAll { it.success }
        if (!ok) return 0.0
        long totalMs = ok.collect { (it.totalResponseTimeMs ?: 0L) as long }.sum() as long
        if (totalMs == 0) return 0.0
        int threads = ok.collect { it.concurrentUserId }.unique().size() ?: 1
        return (ok.size() / (totalMs / threads / 1000.0)).round(2)
    }

    /**
     * Compute averaged summary row for one endpoint.
     * Token/timing fields for NonStreaming endpoints are stored as "-".
     */
    static Map computeAverages(Map ep, List<Map> results) {
        String id           = ConfigLoader.idOf(ep)
        String name         = ConfigLoader.nameOf(ep)
        String endpointType = ep.endpointtype ?: ""
        String responseType = ep.responsetype ?: "Streaming"
        boolean streaming   = responseType.equalsIgnoreCase("Streaming")
        String environment  = ep._environment ?: ""

        List<Map> ok    = results.findAll { it.success }
        int totalRuns   = results.size()
        int successCount = ok.size()

        Closure avg = { String key ->
            List<Double> vals = ok.collect { r ->
                def v = r[key]
                (v != null && v != "-" && v != "") ? (v as double) : null
            }.findAll { it != null && it > 0 }
            vals ? (vals.sum() / vals.size()).round(2) : 0.0
        }

        return [
            endpointId:             id,
            endpointName:           name,
            endpointType:           endpointType,
            responseType:           responseType,
            environment:            environment,
            totalRuns:              totalRuns,
            successCount:           successCount,
            failureCount:           totalRuns - successCount,
            successRate:            totalRuns > 0 ? ((successCount / totalRuns) * 100).round(1) : 0.0,
            avgStreamStartTimeMs:   avg("streamStartTimeMs"),
            avgTimeToFirstTokenMs:  streaming ? avg("timeToFirstTokenMs")  : "-",
            avgTimeToLastTokenMs:   streaming ? avg("timeToLastTokenMs")   : "-",
            avgTotalResponseTimeMs: avg("totalResponseTimeMs"),
            avgInputTokens:         avg("inputTokens"),
            avgOutputTokens:        streaming ? avg("outputTokens")        : "-",
            throughputReqPerSec:    computeThroughput(results)
        ]
    }

    static void resetCounters() {
        totalFailures.set(0)
        totalExecutions.set(0)
    }

    static void logFailureSummary() {
        int f = totalFailures.get()
        int t = totalExecutions.get()
        String msg = "Run summary: ${t - f}/${t} succeeded | ${f} failed"
        if (f > 0) KeywordUtil.markWarning(msg) else KeywordUtil.logInfo(msg)
    }
}
