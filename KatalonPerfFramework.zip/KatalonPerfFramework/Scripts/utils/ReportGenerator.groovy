package utils

import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.*
import org.apache.poi.ss.util.CellRangeAddress
import java.text.SimpleDateFormat
import com.kms.katalon.core.util.KeywordUtil

/**
 * ReportGenerator – Excel report builder.
 *
 * NonStreaming endpoints show "-" for: Time to First Token, Time to Last Token, Output Tokens.
 * All other metrics are always populated.
 *
 * Sheets produced:
 *   1. Dashboard        – stakeholder KPI overview
 *   2. Summary          – averaged metrics per endpoint (3 runs)
 *   3. Raw Results      – every individual request
 */
class ReportGenerator {

    static final String[] SUMMARY_HEADERS = [
        "Endpoint ID", "Endpoint Name", "Type", "Response Type", "Environment",
        "Total Runs", "Successes", "Failures", "Success Rate (%)",
        "Avg Stream Start (ms)", "Avg Time to First Token (ms)", "Avg Time to Last Token (ms)",
        "Avg Total Response (ms)", "Avg Input Tokens", "Avg Output Tokens",
        "Throughput (req/s)"
    ]

    static final String[] RAW_HEADERS = [
        "Endpoint ID", "Endpoint Name", "Type", "Response Type", "Environment",
        "Method", "Run #", "Virtual User", "Executed At",
        "HTTP Status", "Success", "Error",
        "Stream Start (ms)", "Time to First Token (ms)", "Time to Last Token (ms)",
        "Total Response (ms)", "Input Tokens", "Output Tokens"
    ]

    static String generate(List<Map> summaryRows, List<Map> rawResults, Map settings) {
        String prefix    = settings.report_prefix    ?: "PerfTest"
        String outputDir = settings.output_directory ?: "Reports"
        List   stkHolders = settings.stakeholders    ?: []

        File dir = resolveDir(outputDir)
        if (!dir.exists()) dir.mkdirs()

        String ts       = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())
        File   outFile  = new File(dir, "${prefix}_${ts}.xlsx")
        XSSFWorkbook wb = new XSSFWorkbook()

        Map styles = buildStyles(wb)

        buildDashboard(wb, styles, summaryRows, stkHolders, ts)
        buildSummarySheet(wb, styles, summaryRows)
        buildRawSheet(wb, styles, rawResults)

        FileOutputStream fos = new FileOutputStream(outFile)
        wb.write(fos); fos.close(); wb.close()

        KeywordUtil.logInfo("Report: ${outFile.absolutePath}")
        return outFile.absolutePath
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────

    private static void buildDashboard(XSSFWorkbook wb, Map styles,
                                        List<Map> rows, List stakeholders, String ts) {
        XSSFSheet s = wb.createSheet("Dashboard")
        s.setColumnWidth(0, 7000); s.setColumnWidth(1, 9000)
        (2..9).each { s.setColumnWidth(it, 5500) }

        int r = 0

        // Title bar
        XSSFRow title = s.createRow(r++)
        XSSFCell tc = title.createCell(0)
        tc.setCellValue("API Performance Testing Report")
        tc.setCellStyle(styles.title)
        s.addMergedRegion(new CellRangeAddress(0, 0, 0, 9))
        title.setHeightInPoints(28)

        r++ // spacer

        // Metadata block
        addMeta(s, styles, r++, "Generated At", ts)
        addMeta(s, styles, r++, "Stakeholders", stakeholders.join(", "))
        addMeta(s, styles, r++, "Endpoints Tested", rows.size().toString())
        int totalReqs   = rows ? (rows*.totalRuns.sum()     as int) : 0
        int totalFailed = rows ? (rows*.failureCount.sum()  as int) : 0
        addMeta(s, styles, r++, "Total Requests", totalReqs.toString())
        addMeta(s, styles, r++, "Total Failures", totalFailed.toString())

        r++ // spacer

        // KPI table header
        XSSFRow hdr = s.createRow(r++)
        ["Endpoint Name", "Type", "Response Type", "Env",
         "Avg Response (ms)", "TTFT (ms)", "Output Tokens",
         "Throughput (req/s)", "Success (%)"].eachWithIndex { h, i ->
            XSSFCell c = hdr.createCell(i); c.setCellValue(h); c.setCellStyle(styles.colHeader)
        }

        // KPI data
        rows.each { row ->
            XSSFRow dr = s.createRow(r++)
            setCell(dr, 0, row.endpointName,           styles.data)
            setCell(dr, 1, row.endpointType,            styles.data)
            setCell(dr, 2, row.responseType,            styles.data)
            setCell(dr, 3, row.environment,             styles.data)
            setCell(dr, 4, row.avgTotalResponseTimeMs,  styles.dataNum)
            setCell(dr, 5, row.avgTimeToFirstTokenMs,   styles.dataNum)
            setCell(dr, 6, row.avgOutputTokens,         styles.dataNum)
            setCell(dr, 7, row.throughputReqPerSec,     styles.dataNum)
            setCell(dr, 8, row.successRate,             styles.dataNum)
        }
    }

    // ── Summary sheet ─────────────────────────────────────────────────────────

    private static void buildSummarySheet(XSSFWorkbook wb, Map styles, List<Map> rows) {
        XSSFSheet s = wb.createSheet("Summary (Averages)")
        s.createFreezePane(0, 1)

        // Header
        XSSFRow hdr = s.createRow(0)
        SUMMARY_HEADERS.eachWithIndex { h, i ->
            XSSFCell c = hdr.createCell(i); c.setCellValue(h); c.setCellStyle(styles.colHeader)
        }

        // Data
        rows.eachWithIndex { row, idx ->
            XSSFRow dr = s.createRow(idx + 1)
            XSSFCellStyle rs = (idx % 2 == 0) ? styles.data : styles.dataAlt

            [
                row.endpointId, row.endpointName, row.endpointType, row.responseType, row.environment,
                row.totalRuns, row.successCount, row.failureCount, row.successRate,
                row.avgStreamStartTimeMs, row.avgTimeToFirstTokenMs, row.avgTimeToLastTokenMs,
                row.avgTotalResponseTimeMs, row.avgInputTokens, row.avgOutputTokens,
                row.throughputReqPerSec
            ].eachWithIndex { val, j ->
                setCell(dr, j, val, (j >= 5) ? styles.dataNum : rs)
            }

            // Flag failure rows
            if ((row.failureCount as int) > 0) {
                XSSFCell fc = dr.getCell(7)
                fc?.setCellStyle(styles.failCell)
            }
        }

        // Totals row
        if (rows) {
            XSSFRow tot = s.createRow(rows.size() + 1)
            setCell(tot, 0, "AVERAGES", styles.totalLabel)
            [9, 10, 11, 12, 13, 15].each { col ->
                String cl = colLetter(col)
                XSSFCell c = tot.createCell(col)
                c.setCellValue("=IFERROR(AVERAGEIF(${colLetter(3)}2:${colLetter(3)}${rows.size()+1},\"<>-\",${cl}2:${cl}${rows.size()+1}),\"-\")")
                c.setCellStyle(styles.totalNum)
            }
        }

        SUMMARY_HEADERS.size().times { i ->
            s.autoSizeColumn(i)
            s.setColumnWidth(i, Math.min(s.getColumnWidth(i) + 512, 15000))
        }
    }

    // ── Raw results sheet ─────────────────────────────────────────────────────

    private static void buildRawSheet(XSSFWorkbook wb, Map styles, List<Map> rawResults) {
        XSSFSheet s = wb.createSheet("Raw Results")
        s.createFreezePane(0, 1)

        XSSFRow hdr = s.createRow(0)
        RAW_HEADERS.eachWithIndex { h, i ->
            XSSFCell c = hdr.createCell(i); c.setCellValue(h); c.setCellStyle(styles.colHeader)
        }

        rawResults.eachWithIndex { row, idx ->
            XSSFRow dr = s.createRow(idx + 1)
            XSSFCellStyle rs = (idx % 2 == 0) ? styles.data : styles.dataAlt

            [
                row.endpointId, row.endpointName, row.endpointType, row.responseType, row.environment,
                row.method, row.runNumber, row.concurrentUserId, row.executedAt,
                row.httpStatus, (row.success ? "Yes" : "No"), row.error,
                row.streamStartTimeMs, row.timeToFirstTokenMs, row.timeToLastTokenMs,
                row.totalResponseTimeMs, row.inputTokens, row.outputTokens
            ].eachWithIndex { val, j ->
                // Cols 12-17 are numeric metrics — use numeric style unless value is "-"
                boolean isMetricCol = (j >= 12)
                XSSFCellStyle cs = isMetricCol ? styles.dataNum : rs
                setCell(dr, j, val, cs)
            }

            // Success/fail colour on col 10
            XSSFCell sc = dr.getCell(10)
            sc?.setCellStyle(row.success ? styles.successCell : styles.failCell)
        }

        RAW_HEADERS.size().times { i ->
            s.autoSizeColumn(i)
            s.setColumnWidth(i, Math.min(s.getColumnWidth(i) + 512, 14000))
        }
    }

    // ── Style factory ─────────────────────────────────────────────────────────

    private static Map buildStyles(XSSFWorkbook wb) {
        Closure font = { boolean bold, int size, def colorIdx = null ->
            XSSFFont f = wb.createFont()
            f.setFontName("Arial")
            f.setBold(bold)
            f.setFontHeightInPoints((short)size)
            if (colorIdx != null) f.setColor(colorIdx as short)
            return f
        }

        Closure solidStyle = { byte[] rgb, XSSFFont f = null, boolean centre = false ->
            XSSFCellStyle s = wb.createCellStyle()
            s.setFillForegroundColor(new XSSFColor(rgb))
            s.setFillPattern(FillPatternType.SOLID_FOREGROUND)
            if (f) s.setFont(f)
            if (centre) s.setAlignment(HorizontalAlignment.CENTER)
            s.setBorderBottom(BorderStyle.THIN)
            return s
        }

        XSSFFont whtBold = font(true, 11, IndexedColors.WHITE.index)
        XSSFFont whtBold10 = font(true, 10, IndexedColors.WHITE.index)
        XSSFFont plain = font(false, 10)
        XSSFFont bold  = font(true,  10)

        XSSFCellStyle titleStyle = solidStyle([31, 73, 125] as byte[], whtBold, true)
        titleStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        XSSFCellStyle colHeader = solidStyle([68, 114, 196] as byte[], whtBold10, true)
        colHeader.setWrapText(true)

        XSSFCellStyle data = wb.createCellStyle(); data.setFont(plain); data.setBorderBottom(BorderStyle.HAIR)

        XSSFCellStyle dataAlt = wb.createCellStyle(); dataAlt.setFont(plain)
        dataAlt.setFillForegroundColor(new XSSFColor([221, 235, 247] as byte[]))
        dataAlt.setFillPattern(FillPatternType.SOLID_FOREGROUND)
        dataAlt.setBorderBottom(BorderStyle.HAIR)

        XSSFCellStyle dataNum = wb.createCellStyle(); dataNum.setFont(plain)
        dataNum.setDataFormat(wb.createDataFormat().getFormat("#,##0.00"))
        dataNum.setAlignment(HorizontalAlignment.RIGHT)
        dataNum.setBorderBottom(BorderStyle.HAIR)

        XSSFCellStyle metaLabel = wb.createCellStyle(); metaLabel.setFont(bold)

        XSSFCellStyle totalLabel = solidStyle([255, 230, 153] as byte[], bold)
        XSSFCellStyle totalNum   = solidStyle([255, 230, 153] as byte[], bold)
        totalNum.setDataFormat(wb.createDataFormat().getFormat("#,##0.00"))
        totalNum.setAlignment(HorizontalAlignment.RIGHT)

        XSSFCellStyle successCell = solidStyle([198, 239, 206] as byte[], plain)
        XSSFCellStyle failCell    = solidStyle([255, 199, 206] as byte[], plain)

        return [
            title: titleStyle, colHeader: colHeader,
            data: data, dataAlt: dataAlt, dataNum: dataNum,
            metaLabel: metaLabel,
            totalLabel: totalLabel, totalNum: totalNum,
            successCell: successCell, failCell: failCell
        ]
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static void addMeta(XSSFSheet s, Map styles, int rowIdx, String label, String value) {
        XSSFRow row = s.createRow(rowIdx)
        XSSFCell lc = row.createCell(0); lc.setCellValue(label); lc.setCellStyle(styles.metaLabel)
        XSSFCell vc = row.createCell(1); vc.setCellValue(value)
    }

    private static void setCell(XSSFRow row, int col, def value, XSSFCellStyle style) {
        XSSFCell c = row.createCell(col)
        c.setCellStyle(style)
        if (value == null || value == "-" || value == "") {
            c.setCellValue(value?.toString() ?: "")
        } else if (value instanceof Number) {
            c.setCellValue(value.toDouble())
        } else {
            // Try parsing strings as numbers for metric columns
            try { c.setCellValue((value.toString()) as double) }
            catch (Exception ignored) { c.setCellValue(value.toString()) }
        }
    }

    private static String colLetter(int zeroIdx) {
        int n = zeroIdx + 1; String r = ""
        while (n > 0) { n--; r = (char)('A' + (n % 26)) + r; n = (int)(n / 26) }
        return r
    }

    private static File resolveDir(String path) {
        File f = new File(path)
        if (f.isAbsolute()) return f
        try { return new File(com.kms.katalon.core.configuration.RunConfiguration.getProjectDir(), path) }
        catch (Exception ignored) { return new File(System.getProperty("user.dir"), path) }
    }
}
