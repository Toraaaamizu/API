package utils

/**
 * PerfResult – Holds all timing and token metrics for one request execution.
 * Field names align with the endpoints.json schema:
 *   endpointtype  → "Orchestrator" | "Rag" | ""
 *   responsetype  → "Streaming" | "NonStreaming"
 */
class PerfResult {

    // ── Identity (derived from _id, _name, _environment metadata fields) ─────
    String  endpointId           // from _id
    String  endpointName         // from _name
    String  endpointType         // from endpointtype: "Orchestrator" | "Rag" | ""
    String  responseType         // from responsetype: "Streaming" | "NonStreaming"
    String  environment          // from _environment: "env1" | "env2"
    String  method               // from method: "GET" | "POST"
    String  url                  // from url

    // ── Execution context ─────────────────────────────────────────────────────
    int     runNumber
    int     concurrentUserId
    long    executedAt

    // ── HTTP result ───────────────────────────────────────────────────────────
    int     httpStatus
    boolean success = false
    String  error
    String  responseBody

    // ── Timing metrics (ms) ───────────────────────────────────────────────────
    long    streamStartTimeMs      // connection establishment — always captured
    long    timeToFirstTokenMs     // Streaming only; "-" for NonStreaming
    long    timeToLastTokenMs      // Streaming only; "-" for NonStreaming
    long    totalResponseTimeMs    // always captured

    // ── Token metrics ─────────────────────────────────────────────────────────
    int     inputTokens            // estimated from payload — always captured
    int     outputTokens           // Streaming only; "-" for NonStreaming

    // ── Helpers ───────────────────────────────────────────────────────────────

    boolean isStreaming() {
        return responseType?.equalsIgnoreCase("Streaming")
    }

    Map toMap() {
        return [
            endpointId:           endpointId          ?: "",
            endpointName:         endpointName         ?: "",
            endpointType:         endpointType         ?: "",
            responseType:         responseType         ?: "",
            environment:          environment          ?: "",
            method:               method               ?: "",
            url:                  url                  ?: "",
            runNumber:            runNumber,
            concurrentUserId:     concurrentUserId,
            executedAt:           executedAt ? new Date(executedAt).toString() : "",
            httpStatus:           httpStatus,
            success:              success,
            error:                error                ?: "",
            streamStartTimeMs:    streamStartTimeMs,
            timeToFirstTokenMs:   isStreaming() ? timeToFirstTokenMs  : "-",
            timeToLastTokenMs:    isStreaming() ? timeToLastTokenMs   : "-",
            totalResponseTimeMs:  totalResponseTimeMs,
            inputTokens:          inputTokens,
            outputTokens:         isStreaming() ? outputTokens        : "-"
        ]
    }

    @Override
    String toString() {
        return "[${endpointId} run=${runNumber} user=${concurrentUserId}] " +
               "status=${httpStatus} totalMs=${totalResponseTimeMs} " +
               "ttft=${isStreaming() ? timeToFirstTokenMs : 'N/A'} ok=${success}"
    }
}
