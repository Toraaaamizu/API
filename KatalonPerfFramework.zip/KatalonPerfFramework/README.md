# API Performance Testing Framework — Katalon Studio

## Test Environments

| | ENV 1 | ENV 2 |
|---|---|---|
| **Orchestrator** | `https://10.4.109.209:9090` | `https://10.4.109.209:9010` |
| **RAG** | `https://10.4.109.209:9091` | `https://10.4.109.209:9001` |
| **Connected to** | `https://10.10.13.16` | `https://x360edge.xactagov.com:8014` |

---

## Endpoint Inventory (50 endpoints, 25 per environment)

### Orchestrator (19 per env)
| Endpoint | Path | Streaming |
|---|---|---|
| Agent Pipeline Chat Stream | `/agent_pipeline/chat_stream` | ✅ SSE |
| Chat with Document | `/orchestrator/chat_with_document` | ❌ |
| Chat with Artifact | `/orchestrator/chat_with_artifact` | ❌ |
| Chat with Resources | `/orchestrator/chat_with_resources` | ❌ |
| Enterprise Chat with Project | `/orchestrator/enterprise_chat_with_project` | ❌ |
| AI Assist – Custom AI Field | `/orchestrator/ai_assist` | ❌ |
| AI Assist – Control Implementation | `/orchestrator/ai_assist` | ❌ |
| AI Assist – Control Validation | `/orchestrator/ai_assist` | ❌ |
| AI Assist – Risk Registry | `/orchestrator/ai_assist` | ❌ |
| AI Assist – Remediation Plan | `/orchestrator/ai_assist` | ❌ |
| Velocity | `/orchestrator/velocity` | ❌ |
| Images – Add Image | `/images/add_image` | ❌ |
| Images – Analyse Image | `/images/analyse_image` | ❌ |
| Images – Query Image | `/images/query_image` | ❌ |
| Field Tagging – Tag | `/field_tagging/tag` | ❌ |
| Confidence – Single | `/confidence/control_implementation_confidence` | ❌ |
| Confidence – Batch | `/confidence/control_implementation_confidence_batch` | ❌ |
| Job Handler – Field Tagging | `/job_handler/get_job` | ❌ |
| Job Handler – Batch Confidence | `/job_handler/get_job` | ❌ |

### RAG (6 per env)
| Endpoint | Path |
|---|---|
| Add Files – General | `/rag_handler/add_files` |
| Add Files – Temp | `/rag_handler/add_files` |
| Add Files – SCAP | `/rag_handler/add_files` |
| Remove Files – General | `/rag_handler/remove_files` |
| Remove Files – Temp | `/rag_handler/remove_files` |
| LLM Generate Prompt Dict | `/llm/generate_prompt_dict` |

---

## Project Structure

```
KatalonPerfFramework/
├── config/
│   └── endpoints.json                       ← All 50 endpoints (both envs)
├── Data Files/
│   └── rag_queries.json                     ← RAG scenario injection payloads
├── Scripts/
│   ├── perf/
│   │   ├── PerformanceTestRunner.groovy     ← Run ALL endpoints (both envs)
│   │   ├── EnvironmentTest.groovy           ← Run one env: -Dperf.env=env1|env2
│   │   ├── CrossEnvironmentComparisonTest.groovy  ← Side-by-side ENV1 vs ENV2 report
│   │   ├── StreamingEndpointTest.groovy     ← Streaming SSE endpoints only
│   │   ├── OrchestratorEndpointTest.groovy  ← Orchestrator endpoints only
│   │   └── RAGEndpointTest.groovy           ← RAG endpoints + scenario injection
│   └── utils/
│       ├── PerfHttpClient.groovy            ← HTTP engine (GET/POST + SSE)
│       ├── PerfResult.groovy                ← Metrics data model
│       ├── ConfigLoader.groovy              ← JSON config + CLI + env filtering
│       ├── ConcurrentRunner.groovy          ← Thread pool + averages
│       └── ReportGenerator.groovy           ← Excel builder (Apache POI)
├── Test Suites/
│   └── FullPerformanceSuite.ts
└── Profiles/
    └── perf_profile.glbl
```

---

## Quick Start

### Step 1 — Set placeholder values

The following `{{PLACEHOLDER}}` tokens must be resolved before running. Pass them as system properties:

| Placeholder | Description |
|---|---|
| `AUTH_TOKEN` | Bearer token for API authentication |
| `TEST_DOCUMENT_ID` | A valid document ID in the system |
| `TEST_ARTIFACT_ID` | A valid artifact ID |
| `TEST_PROJECT_ID` | A valid project ID |
| `TEST_RESOURCE_ID_1/2` | Valid resource IDs |
| `TEST_IMAGE_URL` | Accessible image URL for add_image |
| `TEST_IMAGE_ID` | An already-added image ID |
| `TEST_FILE_ID_1/2` | Valid file IDs for RAG ingestion |
| `TEST_SCAP_FILE_ID` | A SCAP XML file ID |
| `TEST_FIELD_TAGGING_JOB_ID` | An existing field tagging job ID |
| `TEST_CONFIDENCE_BATCH_JOB_ID` | An existing batch confidence job ID |

### Step 2 — Run tests

#### All endpoints, both environments
```bash
katalonc -projectPath="." \
  -testSuitePath="Test Suites/FullPerformanceSuite" \
  -executionProfile="perf_profile" \
  -DAUTH_TOKEN="Bearer eyJ..." \
  -DTEST_DOCUMENT_ID="doc-abc123" \
  -DTEST_PROJECT_ID="proj-xyz789"
```

#### Single environment
```bash
# ENV1 only
katalonc ... -Dperf.env=env1

# ENV2 only  
katalonc ... -Dperf.env=env2
```

#### ENV1 vs ENV2 side-by-side comparison
```bash
katalonc -projectPath="." \
  -testCasePath="Scripts/perf/CrossEnvironmentComparisonTest" \
  -DAUTH_TOKEN="Bearer eyJ..."
```

#### Single endpoint (no config file needed)
```bash
katalonc -projectPath="." \
  -testCasePath="Scripts/perf/PerformanceTestRunner" \
  -Dperf.url="https://10.4.109.209:9090/agent_pipeline/chat_stream" \
  -Dperf.method=POST \
  -Dperf.name="Chat Stream Adhoc" \
  -Dperf.type=Orchestrator \
  -Dperf.streaming=true \
  -Dperf.body='{"message":"Hello","stream":true}' \
  -DAUTH_TOKEN="Bearer eyJ..."
```

#### Filter by type
```bash
# RAG only
katalonc ... -Dperf.type=RAG

# Orchestrator only
katalonc ... -Dperf.type=Orchestrator
```

---

## Metrics Collected

| Metric | Streaming | Non-Streaming |
|---|---|---|
| Stream Start Time (ms) | ✅ | ✅ |
| Time to First Token (ms) | ✅ | ❌ |
| Time to Last Token (ms) | ✅ | ❌ |
| Total Response Time (ms) | ✅ | ✅ |
| Input Tokens (estimated) | ✅ | ✅ |
| Output Tokens (counted) | ✅ | ❌ |
| Throughput (req/s) | ✅ | ✅ |
| Success Rate (%) | ✅ | ✅ |
| HTTP Status Code | ✅ | ✅ |

---

## Excel Reports Generated

Each test run produces one or more `.xlsx` files in `Reports/`:

| Report File | Contents |
|---|---|
| `PerfTest_<ts>.xlsx` | All endpoints, both environments |
| `PerfTest_ENV1_<ts>.xlsx` | ENV1 endpoints only |
| `PerfTest_ENV2_<ts>.xlsx` | ENV2 endpoints only |
| `PerfTest_ENV_COMPARISON_<ts>.xlsx` | Side-by-side ENV1 vs ENV2 with delta columns |
| `StreamingTest_<ts>.xlsx` | Streaming endpoints only |
| `Orchestrator_<ts>.xlsx` | Orchestrator endpoints only |
| `RAG_<ts>.xlsx` | RAG endpoints only |

Each report has three sheets: **Dashboard** (stakeholder KPI view), **Summary (Averages)** (averaged across 3 runs), and **Raw Results** (every individual request).

The comparison report highlights ENV2 improvements in green and regressions in red.

---

## Stakeholders

Reports are distributed to: Jeff, Andy, Richmond, Chay, Subha, Lakshmi, Patrick, Hugh.

Configure email delivery in `Test Suites/FullPerformanceSuite.ts` → `mailRecipient` field, or share the `Reports/` output directory.

---

## Failure Threshold

The suite marks **FAILED** if the overall failure rate exceeds **20%** across all requests. Individual failed requests are logged as warnings with endpoint ID, virtual user, run number, and error message.
