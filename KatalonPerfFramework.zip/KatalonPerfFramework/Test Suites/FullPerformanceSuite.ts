<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Full API Performance Test Suite – runs all enabled endpoints across ENV1 and ENV2</description>
   <n>FullPerformanceSuite</n>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>jeff@company.com, andy@company.com, richmond@company.com, chay@company.com, subha@company.com, lakshmi@company.com, patrick@company.com, hugh@company.com</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>full-performance-suite-001</testSuiteGuid>
   <testCaseLink>
      <guid>perf-runner-tc-001</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/perf/PerformanceTestRunner/PerformanceTestRunner</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
