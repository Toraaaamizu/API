<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Full API Performance Test Suite – runs all enabled endpoints</description>
   <name>FullPerformanceSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>jeff@company.com, andy@company.com, richmond@company.com, chay@company.com, subha@company.com, lakshmi@company.com, patrick@company.com, hugh@company.com</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>perf-full-suite-001</testSuiteGuid>
   <testCaseLink>
      <guid>perf-runner-001</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Scripts/perf/PerformanceTestRunner</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
