<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Runs both ENV1 and ENV2 and produces a side-by-side comparison Excel report</description>
   <n>CrossEnvironmentSuite</n>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>jeff@company.com, andy@company.com, richmond@company.com, chay@company.com, subha@company.com, lakshmi@company.com, patrick@company.com, hugh@company.com</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>cross-env-suite-001</testSuiteGuid>
   <testCaseLink>
      <guid>cross-env-tc-001</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/perf/CrossEnvironmentComparisonTest/CrossEnvironmentComparisonTest</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
